#include <thread>
#include <iostream>
#include <boost/log/core.hpp>
#include <boost/log/trivial.hpp>
#include <boost/log/expressions.hpp>
#include <boost/program_options.hpp>
#include <csi_kafka/kafka.h>
#include <csi_kafka/highlevel_consumer.h>

int main(int argc, char** argv) {
  int32_t kafka_port = 9092;
  std::string topic;
  std::vector<csi::kafka::broker_address> brokers;

 // boost::program_options::options_description desc("options");
 // desc.add_options()
   // ("help", "produce help message")
   // ("topic", boost::program_options::value<std::string>(), "topic")
   // ("broker", boost::program_options::value<std::string>(), "broker")
   // ;

 // boost::program_options::variables_map vm;
 // boost::program_options::store(boost::program_options::parse_command_line(argc, argv, desc), vm);
 // boost::program_options::notify(vm);

 // boost::log::core::get()->set_filter(boost::log::trivial::severity >= boost::log::trivial::info);

 // if(vm.count("help")) {
   // std::cout << desc << std::endl;
   // return 0;
 // }

 // if(vm.count("topic")) {
    topic = "my-topic";
 // } else {
   // std::cout << "--topic must be specified" << std::endl;
   // return 0;
 // }

 // if(vm.count("broker")) {
   // std::string s = vm["broker"].as<std::string>();
   // size_t last_colon = s.find_last_of(':');
   // if(last_colon != std::string::npos)
     // kafka_port = atoi(s.substr(last_colon + 1).c_str());
   // s = s.substr(0, last_colon);

    // now find the brokers...
   // size_t last_separator = s.find_last_of(',');
   // while(last_separator != std::string::npos) {
     // std::string host = s.substr(last_separator + 1);
     // brokers.push_back(csi::kafka::broker_address(host, kafka_port));
     // s = s.substr(0, last_separator);
     // last_separator = s.find_last_of(',');
   // }
    std::string s="192.168.123.10";
    brokers.push_back(csi::kafka::broker_address(s, kafka_port));
 // } else {
   // std::cout << "--broker must be specified" << std::endl;
   // return 0;
 // }

  std::cout << "broker(s)      : ";
  for(std::vector<csi::kafka::broker_address>::const_iterator i = brokers.begin(); i != brokers.end(); ++i) {
    std::cout << i->host_name << ":" << i->port;
    if(i != brokers.end() - 1)
      std::cout << ", ";
  }
  std::cout << std::endl;
  std::cout << "topic          : " << topic << std::endl;


  boost::asio::io_service io_service;
  std::unique_ptr<boost::asio::io_service::work> work(new boost::asio::io_service::work(io_service));
  std::thread bt([&io_service] { io_service.run(); });

  csi::kafka::highlevel_consumer consumer(io_service,topic, 500, 1000000);

  while (consumer.connect(brokers, 1000)) {
    std::this_thread::sleep_for(std::chrono::seconds(5));
    BOOST_LOG_TRIVIAL(info) << "retrying to connect";
  }

  consumer.set_offset(csi::kafka::earliest_available_offset);

  std::thread do_log([&consumer] {
    uint64_t last_rx_msg_total = 0;
    uint64_t last_rx_bytes_total = 0;

    while (true)
    {
      std::this_thread::sleep_for(std::chrono::seconds(1));

      std::vector<csi::kafka::highlevel_consumer::metrics>  metrics = consumer.get_metrics();

      uint32_t rx_msg_total = 0;
      uint32_t rx_bytes_total = 0;
      for (std::vector<csi::kafka::highlevel_consumer::metrics>::const_iterator i = metrics.begin(); i != metrics.end(); ++i)
      {
        rx_msg_total += (*i).total_rx_msg;
       // std::cout<<"received_message:"<<(*i).value()<<std::endl;
        rx_bytes_total += (*i).total_rx_bytes;
      }

      uint64_t msg_per_sec = (rx_msg_total - last_rx_msg_total);
      uint64_t bytes_per_sec = (rx_bytes_total - last_rx_bytes_total);

      last_rx_msg_total = rx_msg_total;
      last_rx_bytes_total = rx_bytes_total;

      if (msg_per_sec)
      {
        BOOST_LOG_TRIVIAL(info) << "kafka: topic: " << consumer.topic() << ", rx " << msg_per_sec << " msg/sec, (" << (bytes_per_sec / (1024 * 1024)) << " MB/s)";
      // std::cout<<"kafka:value"<<consumer.value()<<std::endl;
      }
    }
  });


  consumer.stream_async([](const boost::system::error_code& ec1, csi::kafka::error_codes ec2, std::shared_ptr<csi::kafka::fetch_response::topic_data::partition_data> response) {
    if(ec1 || ec2) {
      BOOST_LOG_TRIVIAL(error) << "stream failed ec1::" << ec1 << " ec2" << csi::kafka::to_string(ec2);
      return;
    }
  });

  while(true)
    std::this_thread::sleep_for(std::chrono::seconds(30));

  consumer.close();

  work.reset();
  io_service.stop();

  return EXIT_SUCCESS;
}
